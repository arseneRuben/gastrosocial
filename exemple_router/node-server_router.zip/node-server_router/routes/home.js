const router = require('express').Router()

router.get('/', (req, res, next) => {
    res.send('<p>home</p>')
})

module.exports = router
