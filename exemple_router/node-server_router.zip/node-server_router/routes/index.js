const router = require('express').Router()

const CONTENT_TYPE_HTML = 'text/html'
const HTTP_OK = 200

router.get('/', function (request, response) {
    response.writeHead(HTTP_OK, { 'Content-Type': CONTENT_TYPE_HTML })
    response.end('<h1>Home page</h1>')
})

module.exports = router
