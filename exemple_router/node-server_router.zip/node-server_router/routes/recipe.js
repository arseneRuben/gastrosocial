const router = require('express').Router()

router.get('/', (req, resp, next) => {
    resp.end('<h1>Home recette</h1>')
})

router.get('/:idRecette', (req, resp, next) => {
    resp.end('<h1>Home recette avec id ' + req.params.idRecette + '</h1>')
})

module.exports = router
