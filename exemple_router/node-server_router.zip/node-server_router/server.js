'use strict'
const express = require('express')
const app = express()
const indexRouter = require('./routes/index.js')
const homeRouter = require('./routes/home.js')
const recipeRouter = require('./routes/recipe.js')
// parse application/x-www-form-urlencoded
app.use(express.urlencoded({ extended: true }))

// parse application/json
app.use(express.json())
app.use('/', indexRouter)
app.use('/home', homeRouter)
app.use('/recipe', recipeRouter)

const PORT = 8888

// Only to show node-fs-client
// CORS for development only
// https://enable-cors.org/server_expressjs.html
app.use(function (request, response, next) {
    response.header('Access-Control-Allow-Origin', '*')
    response.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept')
    response.header('Access-Control-Allow-Methods', 'POST, PUT, GET, DELETE, OPTIONS')
    response.header('Access-Control-Allow-Credentials', 'false')
    next()
})

app.listen(PORT, function () {
    console.log('Server listening on: http://localhost:%s', PORT)
})
